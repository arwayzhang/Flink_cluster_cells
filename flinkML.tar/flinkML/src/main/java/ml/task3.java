package ml;

import java.io.Serializable;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.java.functions.FunctionAnnotation.ForwardedFields;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.tuple.Tuple5;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
//import org.apache.flink.examples.java.clustering.util.KMeansData;
import org.apache.flink.api.java.DataSet;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.operators.IterativeDataSet;
import org.apache.flink.api.common.operators.Order;
import org.apache.flink.util.Collector;

public class task3{

	public static void main(String[] args) throws Exception {

		// Checking input parameters
		final ParameterTool params = ParameterTool.fromArgs(args);

		// set up execution environment
		ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();
		env.getConfig().setGlobalJobParameters(params); // make parameters available in the web interface

		// read the points and centroids from the provided paths or fall back to default data
		DataSet<Point> points = getPointDataSet(params, env);
		DataSet<Centroid> centroids = getCentroidDataSet(params, env);

		// set number of bulk iterations for KMeans algorithm
		IterativeDataSet<Centroid> loop = centroids.iterate(params.getInt("iterations", 10));

		DataSet<Centroid> newCentroids = points
			// compute closest centroid for each point
			.map(new SelectNearestCenter()).withBroadcastSet(loop, "centroids")
			// count and sum point coordinates for each centroid
			.map(new CountAppender())
			.groupBy(0).reduce(new CentroidAccumulator())
			// compute new centroids from point counts and coordinate sums
			.map(new CentroidAverager());

		// feed new centroids back into next iteration
		DataSet<Centroid> finalCentroids = loop.closeWith(newCentroids);

		DataSet<Tuple3<Integer, Double, Point>> clusteredPoints = points
			// assign points to final clusters
			.map(new SelectNearestCenterDis()).withBroadcastSet(finalCentroids, "centroids");
		
		
		
		DataSet<Tuple2<Integer, Integer>> clusteridcount = clusteredPoints
				.map(tuple -> new Tuple2<Integer, Integer>(tuple.f0, 1));
		
		DataSet<Tuple2<Integer, Integer>> clusteridsumini = 
				clusteridcount.groupBy(0)
				              .sum(1)
				              .map(tuple -> new Tuple2<Integer, Integer>(tuple.f0, tuple.f1));
		
		DataSet<Tuple2<Integer, Integer>> clusteridsum =
				clusteridsumini.sortPartition(0, Order.ASCENDING);
		
		
		DataSet<Tuple4<Integer, Integer, Double, Point>> results = clusteridsum
				.join(clusteredPoints)
				.where(0)
				.equalTo(0)
				.projectFirst(0, 1)
				.projectSecond(1, 2);
		

		
	    DataSet<Tuple4<Integer, Integer, Double, Point>> sortedesults =
	    		results.sortPartition(0, Order.ASCENDING)
	    		       .sortPartition(1, Order.ASCENDING);
	    
	    DataSet<Point> fliteredresults =
	    		sortedesults.groupBy(0)
	    		            .sortGroup(2, Order.ASCENDING)
	    		            .reduceGroup((tuples, out) -> {
	    		            	Integer count =0;
	    		            	for (Tuple4<Integer, Integer, Double, Point> tuple : tuples) {
	    		            		Integer max =tuple.f1;
	    		            		count += 1;
	    		            		if (count >= max*0.9) {
	    		            			break;
	    		            			
	    		            		}
	    		            		out.collect(tuple.f3);
	    		            	}
	    		            	
	    		            	
	    		            });

//////////again////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	    DataSet<Point> points2 = fliteredresults;
		DataSet<Centroid> centroids2 = finalCentroids;

		// set number of bulk iterations for KMeans algorithm
		IterativeDataSet<Centroid> loop2 = centroids2.iterate(params.getInt("iterations", 10));

		DataSet<Centroid> newCentroids2 = points2
			// compute closest centroid for each point
			.map(new SelectNearestCenter()).withBroadcastSet(loop2, "centroids")
			// count and sum point coordinates for each centroid
			.map(new CountAppender())
			.groupBy(0).reduce(new CentroidAccumulator())
			// compute new centroids from point counts and coordinate sums
			.map(new CentroidAverager());

		// feed new centroids back into next iteration
		DataSet<Centroid> finalCentroids2 = loop2.closeWith(newCentroids2);

		
		DataSet<Tuple4<Integer, Double, Double, Double>> finalCentroidsplit2 = 
				finalCentroids2.map(new centroidtotuple());
		
		
		
		DataSet<Tuple2<Integer, Point>> clusteredPoints2 = points2
			// assign points to final clusters
			.map(new SelectNearestCenter()).withBroadcastSet(finalCentroids2, "centroids");
		
		
		
		DataSet<Tuple2<Integer, Integer>> clusteridcount2 = clusteredPoints2
				.map(tuple -> new Tuple2<Integer, Integer>(tuple.f0, 1));
		
		DataSet<Tuple2<Integer, Integer>> clusteridsumini2 = 
				clusteridcount2.groupBy(0)
				              .sum(1)
				              .map(tuple -> new Tuple2<Integer, Integer>(tuple.f0, tuple.f1));
		
		DataSet<Tuple2<Integer, Integer>> clusteridsum2 =
				clusteridsumini2.sortPartition(0, Order.ASCENDING);
		
		
		DataSet<Tuple5<Integer, Integer, Double, Double, Double>> results2 = clusteridsum2
				.join(finalCentroidsplit2)
				.where(0)
				.equalTo(0)
				.projectFirst(0, 1)
				.projectSecond(1,2,3);
        

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	    

		// emit result
		results2.writeAsCsv(params.get("output"), "\n", "\t");
		env.execute("KMeans Example");
	}


/////Data///////////////////////////////////////////////////////////
	
	public static final Object[][] CENTROIDS = new Object[][] {
		new Object[] {1,0.00,0.00,0.00},
		new Object[]{2,10.00,0.00,2.00},
		new Object[]{3,0.00,10.00,0.00},
		new Object[]{4,10.00,0.00,0.00}
	};
	

	
	public static DataSet<Centroid> getDefaultCentroidDataSet(ExecutionEnvironment env) {
		List<Centroid> centroidList = new LinkedList<Centroid>();
		for (Object[] centroid : CENTROIDS) {
			centroidList.add(
					new Centroid((Integer) centroid[0], (Double) centroid[1], (Double) centroid[2], (Double) centroid[3]));
		}
		return env.fromCollection(centroidList);
	}

	public static class centroidtotuple implements MapFunction<Centroid, Tuple4<Integer, Double, Double, Double>> {
		  @Override
		  public Tuple4<Integer, Double, Double, Double> map(Centroid c) {
			  Object[] values = c.tosplit();
			  return new Tuple4<>((Integer) values[0], (Double) values[1], (Double) values[2], (Double) values[3]);
		  }
	}
	
	private static DataSet<Centroid> getCentroidDataSet(ParameterTool params, ExecutionEnvironment env) {
		DataSet<Centroid> centroids=
				getDefaultCentroidDataSet(env);

		return centroids;
	}
	

	private static DataSet<Point> getPointDataSet(ParameterTool params, ExecutionEnvironment env) {
		String measuredir =params.getRequired("input1");
		DataSet<Point> points=
				env.readCsvFile(measuredir)
				.ignoreFirstLine()
				.includeFields("11100011000100000")
				.types(String.class, Integer.class, Integer.class, Double.class, Double.class, Double.class)
				.filter(tuple -> {

                    if (tuple.f1>=1 & tuple.f1<=150000 & tuple.f2>=1 & tuple.f2<=150000) {
                            return true;
                    }else{

                            return false;

                    }

                }

            ).map(tuple -> new Point(tuple.f5,tuple.f4,tuple.f3));
		return points;
	}


	public static class Point implements Serializable {

		public double x, y, z;

		public Point() {}

		public Point(double x, double y, double z) {
			this.x = x;
			this.y = y;
			this.z = z;
		}

		public Point add(Point other) {
			x += other.x;
			y += other.y;
			z += other.z;
			return this;
		}

		public Point div(long val) {
			x /= val;
			y /= val;
			z /= val;
			return this;
		}

		public double euclideanDistance(Point other) {
			return Math.sqrt((x-other.x)*(x-other.x) + (y-other.y)*(y-other.y) + (z-other.z)*(z-other.z));
		}

		public void clear() {
			x = y = z = 0.0;
		}

		@Override
		public String toString() {
			return x + " " + y + " " + z;
		}	
		
		
	}


	public static class Centroid extends Point {

		public int id;

		public Centroid() {}

		public Centroid(int id, double x, double y, double z) {
			super(x,y,z);
			this.id = id;
		}

		public Centroid(int id, Point p) {
			super(p.x, p.y, p.z);
			this.id = id;
		}

		@Override
		public String toString() {
			return id + " " + super.toString();
		}
		
        public Object[] tosplit() {
        	Object[] values =new Object[] {id, x, y, z};
        	return values;
        }
		
		
		
	}


	public static final class SelectNearestCenter extends RichMapFunction<Point, Tuple2<Integer, Point>> {
		private Collection<Centroid> centroids;


		public void open(Configuration parameters) throws Exception {
			this.centroids = getRuntimeContext().getBroadcastVariable("centroids");
		}


		public Tuple2<Integer, Point> map(Point p) throws Exception {

			double minDistance = Double.MAX_VALUE;
			int closestCentroidId = -1;

			// check all cluster centers
			for (Centroid centroid : centroids) {
				// compute distance
				double distance = p.euclideanDistance(centroid);

				// update nearest cluster if necessary
				if (distance < minDistance) {
					minDistance = distance;
					closestCentroidId = centroid.id;
				}
			}

			// emit a new record with the center id and the data point.
			return new Tuple2<>(closestCentroidId, p);
		}
	}

	
	public static final class SelectNearestCenterDis extends RichMapFunction<Point, Tuple3<Integer, Double, Point>> {
		private Collection<Centroid> centroids;


		public void open(Configuration parameters) throws Exception {
			this.centroids = getRuntimeContext().getBroadcastVariable("centroids");
		}


		public Tuple3<Integer, Double, Point> map(Point p) throws Exception {

			double minDistance = Double.MAX_VALUE;
			int closestCentroidId = -1;

			// check all cluster centers
			for (Centroid centroid : centroids) {
				// compute distance
				double distance = p.euclideanDistance(centroid);

				// update nearest cluster if necessary
				if (distance < minDistance) {
					minDistance = distance;
					closestCentroidId = centroid.id;
				}
			}

			// emit a new record with the center id and the data point.
			return new Tuple3<>(closestCentroidId, minDistance, p);
		}
	}
	
	

	public static final class CountAppender implements MapFunction<Tuple2<Integer, Point>, Tuple3<Integer, Point, Long>> {


		public Tuple3<Integer, Point, Long> map(Tuple2<Integer, Point> t) {
			return new Tuple3<>(t.f0, t.f1, 1L);
		}
	}


	public static final class CentroidAccumulator implements ReduceFunction<Tuple3<Integer, Point, Long>> {


		public Tuple3<Integer, Point, Long> reduce(Tuple3<Integer, Point, Long> val1, Tuple3<Integer, Point, Long> val2) {
			return new Tuple3<>(val1.f0, val1.f1.add(val2.f1), val1.f2 + val2.f2);
		}
	}


	public static final class CentroidAverager implements MapFunction<Tuple3<Integer, Point, Long>, Centroid> {


		public Centroid map(Tuple3<Integer, Point, Long> value) {
			return new Centroid(value.f0, value.f1.div(value.f2));
		}
	}
}

