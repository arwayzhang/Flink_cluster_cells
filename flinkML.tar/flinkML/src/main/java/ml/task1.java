package ml;


import org.apache.flink.api.common.operators.Order;
import org.apache.flink.api.java.DataSet;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.utils.ParameterTool;

import org.apache.flink.configuration.GlobalConfiguration;


public class task1{
	public static void main(String[] args) throws Exception {
        final ParameterTool params = ParameterTool.fromArgs(args);
		final ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();

		String measuredir =params.getRequired("input1");
		String experidir =params.getRequired("input2");
		
        DataSet<Tuple2<String, Integer>> samplecount =
                env.readCsvFile(measuredir)
                     .ignoreFirstLine()
                     .includeFields("11100000000000000")
                     .types(String.class, Integer.class, Integer.class)
                     .filter(tuple -> {

                         if (tuple.f1>=1 & tuple.f1<=150000 & tuple.f2>=1 & tuple.f2<=150000) {
                                 return true;
                         }else{

                                 return false;

                         }

                     }

                 ).map(tuple -> new Tuple2<String,Integer>(tuple.f0,1));

        DataSet<Tuple2<String, String>> sampleresearcher =
                env.readTextFile(experidir)
                    .flatMap((line, out) -> {
                        String[] values = line.split(",");

                        if(values.length >= 8) {
                            String sample = values[0];
                            String[] researchers = values[values.length - 1].split(";");

                            for(String researcher : researchers) {
                                out.collect(new Tuple2<String, String>(sample, researcher.trim()));
                            }
                        }
                    });		


        
        
        DataSet<Tuple3<String, String, Integer>> sampleresearchercount =
        		sampleresearcher
                    .join(samplecount)
                    .where(0)
                    .equalTo(0)
                    .projectFirst(0, 1)
                    .projectSecond(1);

        DataSet<Tuple2<String, Integer>> researchercount =
        		sampleresearchercount
                    .map(tuple -> new Tuple2<String, Integer>(tuple.f1, tuple.f2));        
        
        DataSet<Tuple2<String, Integer>> researchersum =
        		researchercount
                    .groupBy(0)
                    .sum(1); // Sum of all ratings.
                    

        
        
        DataSet<Tuple2<String, Integer>> result = researchersum
                //.partitionByRange(1)
                .sortPartition(1, Order.DESCENDING);



        
        result.writeAsCsv(params.get("output"),"\n","\t");
		
		env.execute();
		
		
	}
	
	
	
}
